<?php $__env->startSection('page'); ?>

<div class="container mt-5">
    <div class="card p-4 shadow">
        <h2 class="text-center mb-4">Edit Resume</h2>

<form action="<?php echo e(route('resumes.update', $resume->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

            <h4 class="text-primary">Basic Information</h4>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Name</label>
                    <input type="text" name="name" value="<?php echo e($resume->name); ?>" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo e($resume->email); ?>" class="form-control" required>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Profession Title</label>
                    <input type="text" name="profession_title" value="<?php echo e($resume->profession_title); ?>" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label>Location</label>
                    <input type="text" name="location" value="<?php echo e($resume->location); ?>" class="form-control">
                </div>
            </div>

            <div class="mb-3">
                <label>Cover Image</label><br>
                <?php if($resume->cover_image): ?>
                    <img src="<?php echo e(asset('storage/' . $resume->cover_image)); ?>" class="mb-2" height="80">
                <?php endif; ?>
                <input type="file" name="cover_image" class="form-control">
            </div>

            <hr>
            <h4 class="text-primary mt-4">Education</h4>
            <?php $__currentLoopData = $resume->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border p-3 rounded mb-3">
                    <div class="row">
                        <div class="col-md-4">
                            <label>Degree</label>
                            <input type="text" name="educations[<?php echo e($index); ?>][degree]" class="form-control" value="<?php echo e($edu->degree); ?>">
                        </div>
                        <div class="col-md-4">
                            <label>Field of Study</label>
                            <input type="text" name="educations[<?php echo e($index); ?>][field_of_study]" class="form-control" value="<?php echo e($edu->field_of_study); ?>">
                        </div>
                        <div class="col-md-4">
                            <label>School</label>
                            <input type="text" name="educations[<?php echo e($index); ?>][school]" class="form-control" value="<?php echo e($edu->school); ?>">
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr>
            <h4 class="text-primary mt-4">Experience</h4>
            <?php $__currentLoopData = $resume->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border p-3 rounded mb-3">
                    <div class="row">
                        <div class="col-md-6">
                            <label>Company Name</label>
                            <input type="text" name="experiences[<?php echo e($index); ?>][company_name]" class="form-control" value="<?php echo e($exp->company_name); ?>">
                        </div>
                        <div class="col-md-6">
                            <label>Title</label>
                            <input type="text" name="experiences[<?php echo e($index); ?>][title]" class="form-control" value="<?php echo e($exp->title); ?>">
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <hr>
            <h4 class="text-primary mt-4">Skills</h4>
            <?php $__currentLoopData = $resume->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border p-3 rounded mb-3">
                    <div class="row">
                        <div class="col-md-8">
                            <label>Skill Name</label>
                            <input type="text" name="skills[<?php echo e($index); ?>][skill_name]" class="form-control" value="<?php echo e($skill->skill_name); ?>">
                        </div>
                        <div class="col-md-4">
                            <label>Skill Percent</label>
                            <input type="number" name="skills[<?php echo e($index); ?>][skill_percent]" class="form-control" value="<?php echo e($skill->skill_percent); ?>">
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="text-center mt-4">
                <button type="submit" class="btn btn-primary w-100">Update Resume</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel-practice\laravel-project\resources\views\pages\resumes\edit-resume.blade.php ENDPATH**/ ?>