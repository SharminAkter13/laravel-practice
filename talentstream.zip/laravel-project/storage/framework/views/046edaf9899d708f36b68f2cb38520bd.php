<?php $__env->startSection('page'); ?>
<div class="card bg-primary-subtle p-5 w-100">
  <!-- Full-width background container -->
  <div class="bg-info-subtle p-5 rounded w-100 mt-5">
    
    <!-- Centered form inside full-width container -->
    <div class="d-flex justify-content-center">
      <form method="POST" action="<?php echo e(route('editStoreU')); ?>" class="w-100" style="max-width: 500px;">
        <?php echo csrf_field(); ?>
        <h1 class="text-center mb-4">Update Users</h1>

        <input type="text" name="uegory_id" class="form-control" hidden value="<?php echo e($u->id); ?>">

        <div class="mb-3">
          <label class="form-label">Name</label>
          <input type="text" name="name" class="form-control" required value="<?php echo e($u->name); ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Email</label>
          <input type="number" name="email" class="form-control" required value="<?php echo e($u->email); ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="number" name="password" class="form-control" required value="<?php echo e($u->password); ?>">
        </div>

        <div class="text-center">
          <button type="submit" class="btn btn-primary form-control">Update</button>
        </div>
      </form>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel-practice\laravel-project\resources\views\pages\interview\edit-int.blade.php ENDPATH**/ ?>