@include('portal_layouts.header')

<div class="main-content"> 

    @include('portal_layouts.navbar')

    @yield('content') 

    @include('portal_layouts.footer')

</div>